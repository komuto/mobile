/**
 * https://github.com/facebook/react-native/blob/master/Libraries/Utilities/Alert.js
 */
const Alert = {
  alert(title, message, buttons, type) {

  },
};

module.exports = Alert;
