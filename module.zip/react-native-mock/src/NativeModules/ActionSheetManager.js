
const ActionSheetManager = {
  showActionSheetWithOptions(options, callback) {

  },
  showShareActionSheetWithOptions(options, failure, success) {

  },
};

module.exports = ActionSheetManager;
