/**
 * https://github.com/facebook/react-native/blob/master/React/Modules/RCTTiming.m
 */
const Timing = {
  createTimer(callbackId, duration, jsSchedulingTime, repeats) {

  },
  deleteTimer(timerId) {

  },
};

module.exports = Timing;
