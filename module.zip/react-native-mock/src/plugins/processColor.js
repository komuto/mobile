function processColor() {
  // TODO(lmr): seems like a good example of something we should pull directly from RN.
  return 0;
}

module.exports = processColor;
