declare module "react-native-splash-screen" {
    export default class SplashScreen {
        static hide(): void;
    }
}
