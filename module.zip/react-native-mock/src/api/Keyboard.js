const Keyboard = {
  addListener(eventname, handler) {
    return {
      remove: () => {}
    };
  },
  removeListener: () => {},
  removeAllListeners: () => {},
  dismiss: () => {}
};

module.exports = Keyboard;
