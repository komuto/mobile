const EventEmitter = require('events').EventEmitter;

const DeviceEventEmitter = new EventEmitter();

module.exports = DeviceEventEmitter;
