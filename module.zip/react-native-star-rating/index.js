// Local file imports
import StarRating from './star-rating';

export default StarRating;
