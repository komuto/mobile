### Version
Tell us which versions you are using: 

- react-native-image-crop-picker v0.?.?
- react-native v0.?.?

### Platform
Tell us to which platform this issue is related

- iOS
- Android

### Expected behaviour



### Actual behaviour



### Steps to reproduce

1.

2.

3.

### Attachments

// stacktrace or any other useful debug info
