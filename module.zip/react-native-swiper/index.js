import Swiper from './src/'
module.exports = Swiper
