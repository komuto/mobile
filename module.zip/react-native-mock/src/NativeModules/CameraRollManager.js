
const CameraRollManager = {
  saveImageWithTag(imageTag) {
    return Promise.resolve(['/asset/url']);
  },
  getPhotos(params) {
    return Promise.resolve([
      // TODO(lmr):
    ]);
  },
};

module.exports = CameraRollManager;
