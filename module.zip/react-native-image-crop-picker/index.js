import React from 'react';

import {NativeModules} from 'react-native';
export default NativeModules.ImageCropPicker;
