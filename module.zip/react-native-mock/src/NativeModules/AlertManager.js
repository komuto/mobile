/**
 * https://github.com/facebook/react-native/blob/master/React/Modules/RCTAlertManager.m
 */
const AlertManager = {
  alertWithArgs(args, callback) {

  },
};

module.exports = AlertManager;
