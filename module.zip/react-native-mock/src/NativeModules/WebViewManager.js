
const WebViewManager = {
  goBack(reactTag) {

  },
  goForward(reactTag) {

  },
  reload(reactTag) {

  },
  startLoadWithResult(result, lockIdentifier) {

  },
  JSNavigationScheme: 'react-js-navigation',
  NavigationType: {
    LinkClicked: 0,
    FormSubmitted: 1,
    BackForward: 2,
    Reload: 3,
    FormResubmitted: 4,
    Other: 5,
  }
};

module.exports = WebViewManager;
