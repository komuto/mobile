/**
 * https://github.com/facebook/react-native/blob/master/Libraries/Animated/src/Interpolation.js
 */
class Interpolation {
  static create(config) {
    // TODO(lmr):
  }
}

module.exports = Interpolation;
