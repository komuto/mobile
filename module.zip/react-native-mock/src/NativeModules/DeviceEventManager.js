const DeviceEventManager = {
  invokeDefaultBackPressHandler() {

  },
};

module.exports = DeviceEventManager;
