import RadioForm, {RadioButton, RadioButtonInput, RadioButtonLabel} from './lib/SimpleRadioButton.js'
// module.exports = Radio
// module.exports = RadioButton


export default RadioForm
export {RadioButton, RadioButtonInput, RadioButtonLabel}
