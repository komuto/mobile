const Vibration = {
  vibrate() {

  },
};

module.exports = Vibration;
