const EventEmitter = require('events').EventEmitter;

const NativeAppEventEmitter = new EventEmitter();

module.exports = NativeAppEventEmitter;
